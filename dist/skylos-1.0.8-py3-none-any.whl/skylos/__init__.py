from skylos.analyzer import analyze

__version__ = "1.0.8"

def debug_test():
    return "debug-ok"

__all__ = ["analyze", "debug_test", "__version__"]